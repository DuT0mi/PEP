/***************************************************************************//**
 * Includes
 ******************************************************************************/
#include <stdio.h>
#include <FreeRTOS.h>
#include <task.h>

#include "em_device.h"
#include "em_chip.h"

#include "em_cmu.h"
#include <stdint.h>
#include <stdbool.h>

#include "segmentlcd.h"
#include "segmentlcd_individual.h"

#include "stdlib.h" //v�letlen kaja hely gener�l�shoz

#include "uart.h"
#include "snake.h"
#include "timer.h"


extern volatile int UARTvalue;
extern volatile bool UARTflag;
extern volatile bool TIMERflag;
volatile bool UARThappened; //m�shogy kell mozogni
/*
 * "sl_udelay.h" is used only by the demo functions to slow things down.
 * Otherwise it is not required to use the SegmentLCD driver extension.
 */
#include <sl_udelay.h>


/***************************************************************************//**
 * Globals
 ******************************************************************************/

/*
 * SegmentLCD_UpperSegments() and SegmentLCD_LowerSegments() are used to update
 * the display with new data. Display data is expected by these functions to be
 * located in arrays with SegmentLCD_UpperCharSegments_TypeDef and
 * SegmentLCD_LowerCharSegments_TypeDef elements, respectively.
 */
SegmentLCD_UpperCharSegments_TypeDef upperCharSegments[SEGMENT_LCD_NUM_OF_UPPER_CHARS];
SegmentLCD_LowerCharSegments_TypeDef lowerCharSegments[SEGMENT_LCD_NUM_OF_LOWER_CHARS];


/***************************************************************************//**
 * Function definitions
 ******************************************************************************/

/*
 * This function demonstrates the usage of the extension driver for the upper
 * part of the LCD.
 */
void demoUpperSegments() {
   // Turn on all segments one-by-one
   // Only one segment is turned on at any given time
   // Using 7 bit binary (raw) value
   for (uint8_t p = 0; p < SEGMENT_LCD_NUM_OF_UPPER_CHARS; p++) {
      for (uint8_t s = 0; s < 8; s++) {
         upperCharSegments[p].raw = 1 << s;
         SegmentLCD_UpperSegments(upperCharSegments);
         sl_udelay_wait(100000);
      }
   }

   // Turn on all segments one-by-one
   // All the previous segments are left turned on
   // Using dedicated (bit field) values
   for (uint8_t p = 0; p < SEGMENT_LCD_NUM_OF_UPPER_CHARS; p++) {
      upperCharSegments[p].a = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);

      upperCharSegments[p].b = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);

      upperCharSegments[p].c = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);

      upperCharSegments[p].d = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);

      upperCharSegments[p].e = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);

      upperCharSegments[p].f = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);

      upperCharSegments[p].g = 1;
      SegmentLCD_UpperSegments(upperCharSegments);
      sl_udelay_wait(100000);
   }

   // Clear all segments
   for (uint8_t p = 0; p < SEGMENT_LCD_NUM_OF_UPPER_CHARS; p++) {
      upperCharSegments[p].raw = 0;
      SegmentLCD_UpperSegments(upperCharSegments);
   }
}

/*
 * This function demonstrates the usage of the extension driver for the lower
 * part of the LCD.
 */
void demoLowerSegments() {
   // Turn on all segments one-by-one
   // Only one segment is turned on at any given time
   // Using 14 bit binary (raw) value
   for (uint8_t p = 0; p < SEGMENT_LCD_NUM_OF_LOWER_CHARS; p++) {
      for (uint8_t s = 0; s < 15; s++) {
         lowerCharSegments[p].raw = 1 << s;
         SegmentLCD_LowerSegments(lowerCharSegments);
         sl_udelay_wait(100000);
      }
   }

   // Turn on all segments one-by-one
   // All the previous segments are left turned on
   // Using dedicated (bit field) values
   for (uint8_t p = 0; p < SEGMENT_LCD_NUM_OF_LOWER_CHARS; p++) {
      lowerCharSegments[p].a = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].b = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].c = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].d = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].e = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].f = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].g = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].h = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].j = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].k = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].m = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].n = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].p = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);

      lowerCharSegments[p].q = 1;
      SegmentLCD_LowerSegments(lowerCharSegments);
      sl_udelay_wait(100000);
   }

   // Clear all segments
   for (uint8_t p = 0; p < SEGMENT_LCD_NUM_OF_LOWER_CHARS; p++) {
      lowerCharSegments[p].raw = 0;
      SegmentLCD_LowerSegments(lowerCharSegments);
   }
}

void prvTskTest(void){
  while(1){
    CHIP_Init();
    uartinit();
    TimerInit();
    /* Enable LCD without voltage boost */
    SegmentLCD_Init(false);
    /* If first word of user data page is non-zero, enable Energy Profiler trace */

    /* Infinite loop */
    SegmentLCD_AllOff();
    snake mysnake;
    SegmentLCD_LowerCharSegments_TypeDef mydisplay[7];
    bool SymbolFlip=false;

    mysnake=SnakeInit(mysnake);  //pr�ba, hogy megy-e a kirajzol�s stb.
    uint8_t food=PlaceFood(mysnake);  //random helyre most lerakok egy kaj�t
    while (1) {
      /*Beállítunk egy szemafort, a későbbi UART vétel nem jut érvényre*/
      if(UARTflag) {
      //UARTvalue=USART_RxDataGet(UART0); //itt NEM szabad kiolvasni
        UARTflag=false;
        USART_Tx(UART0, UARTvalue);
        UARThappened=true;
      }

      /*Elengedjük az UART-os szemafort*/
      if(TIMERflag) {
       TIMERflag=false;
       if(mysnake.isAlive) {
        if(UARThappened)
          mysnake=NextDirUART(mysnake, UARTvalue);
        else
          mysnake=NextDirNoUART(mysnake);
        UARThappened=false;
          mysnake=MoveSnake(mysnake, &food);
          *mydisplay=SnakeandFoodtoLCD(mysnake, food, mydisplay);
        SegmentLCD_LowerSegments(mydisplay);
       }
       else {
         //mysnake.size=0;
         SegmentLCD_AllOff();
         /*Itt ugye a pontokat villogatatom, lehetne várakozásos ütemezés*/
         if(SymbolFlip) {
           SegmentLCD_Symbol(LCD_SYMBOL_DP2, 1);
           SegmentLCD_Symbol(LCD_SYMBOL_DP3, 1);
           SegmentLCD_Symbol(LCD_SYMBOL_DP4, 1);
           SegmentLCD_Symbol(LCD_SYMBOL_DP5, 1);
           SegmentLCD_Symbol(LCD_SYMBOL_DP6, 1);
           SymbolFlip=false;
         }
         else {
           SegmentLCD_Symbol(LCD_SYMBOL_DP2, 0);
           SegmentLCD_Symbol(LCD_SYMBOL_DP3, 0);
           SegmentLCD_Symbol(LCD_SYMBOL_DP4, 0);
           SegmentLCD_Symbol(LCD_SYMBOL_DP5, 0);
           SegmentLCD_Symbol(LCD_SYMBOL_DP6, 0);
           SymbolFlip=true;
         }
       }
      }
      SegmentLCD_Number(mysnake.size);
    }
  }
}
/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void)
{
/*
  SegmentLCD_Init(false);

  demoLowerSegments();
  demoUpperSegments();
  */

  xTaskCreate(
      prvTskTest, // function pointer, is just the function's name without brackets and params
      "",
      configMINIMAL_STACK_SIZE,
      NULL,
      tskIDLE_PRIORITY + 1, // in freetros the num is bigger than the priority too
      NULL);
}


/***************************************************************************//**
 * App ticking function.
 ******************************************************************************/
void app_process_action(void){

}

