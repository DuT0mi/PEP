/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include <stdio.h>
#include <FreeRTOS.h>
#include <task.h>
#include <em_gpio.h>


/***************************************************************************//**
 * Task handler(s)
 ******************************************************************************/
TaskHandle_t hTaskBtn;

/***************************************************************************//**
 * ISRs.
 ******************************************************************************/
void GPIO_ODD_IRQHandler(){
 BaseType_t xSwitchRequired;
 GPIO_IntClear(1 << 9); // melyik IT/IT-ket szerenénk nyugtázni, minden egyes IT- hez 1 bit van, azért shifteljük mert a "9"-es kell
 xSwitchRequired = xTaskResumeFromISR(hTaskBtn);

 // IT-ból azonnali átütemezés
 portYIELD_FROM_ISR(xSwitchRequired);
}

/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
static void prvTaskBtn(void *pvParam){
  while(1){
      vTaskSuspend(NULL);// Aktuális taszknál null-t kell adni, ha ezt szeretnén felfüggeszteni
      printf("Button has been pressed!\n");
  }
}



void app_init(void){
    GPIO_PinModeSet(gpioPortB, 9, gpioModeInput, false); //pollingra ez már elég
    GPIO_ExtIntConfig(gpioPortB, 9, 9, false,true,true); // kérheti az IT
    NVIC_EnableIRQ(GPIO_ODD_IRQn);  // CPU el is kezdi kiszolgáni az IT

    xTaskCreate(
        prvTaskBtn, // function pointer, is just the function's name without brackets and params
        "Btn", // Debuggereknek és ismerik, hogy freeRtos van akkor hozzá tudják fűzni
        configMINIMAL_STACK_SIZE,
        NULL,
        tskIDLE_PRIORITY + 1, // in freetros the num is bigger than the priority too
        &hTaskBtn);

}

/***************************************************************************//**
 * App ticking function.
 ******************************************************************************/
void app_process_action(void){

}
